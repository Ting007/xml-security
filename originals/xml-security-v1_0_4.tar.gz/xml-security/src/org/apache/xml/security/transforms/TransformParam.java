package org.apache.xml.security.transforms;

/**
 *
 * @author $Author: geuerp $
 */
public interface TransformParam {
}